# F G Jarvis v0.2
1. Upload all files to a GitHub repo -> Actions -> Build -> download APK / EXE.
2. Phone: Setup -> Gemini key; Accessibility; All files access. Tap "Mic ON" (visible notification, STOP button).
3. Voice: say "Jarvis open chrome", "Jarvis call Ali", "Jarvis search weather", "Jarvis girl voice", "Jarvis selfie".
4. Sensitive actions always show a YES notification first.
5. Pair: same Wi-Fi. Phone Setup shows phone code; PC Setup shows PC code. PC: "phone ls /sdcard", "phone get /sdcard/x.jpg", "phone open whatsapp". Phone: "pc open youtube.com".
