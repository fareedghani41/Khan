import tkinter as tk, tkinter.messagebox as mb, tkinter.simpledialog as sd
import threading, math, time, json, os, random, subprocess, webbrowser, http.server, urllib.parse, requests
try: import pyttsx3; tts = pyttsx3.init()
except Exception: tts = None
CFG = os.path.join(os.path.expanduser("~"), ".fgjarvis.json")
def cfg():
    try: return json.load(open(CFG))
    except Exception: return {}
def save(**k): c = cfg(); c.update(k); json.dump(c, open(CFG, "w"))
if "token" not in cfg(): save(token=str(random.randint(10**7, 10**8-1)))
MODELS = ["gemini-2.5-flash", "gemini-2.0-flash", "gemini-2.0-flash-lite", "gemini-1.5-flash"]
SYS = "You are F G, friendly respectful voice assistant of Farid Ghani. Reply short, in the user's language."
talking = False
def ask(q, search=False):
    for m in MODELS:
        try:
            b = {"systemInstruction": {"parts": [{"text": SYS}]}, "contents": [{"role": "user", "parts": [{"text": q}]}]}
            if search: b["tools"] = [{"google_search": {}}]
            r = requests.post(f"https://generativelanguage.googleapis.com/v1beta/models/{m}:generateContent?key={cfg().get('key','')}", json=b, timeout=60)
            if r.ok: return "".join(p.get("text", "") for p in r.json()["candidates"][0]["content"]["parts"]).strip()
        except Exception: pass
    return "Gemini key/internet problem."
root = tk.Tk(); root.title("F G Jarvis"); root.configure(bg="black")
cv = tk.Canvas(root, width=420, height=420, bg="black", highlightthickness=0); cv.pack()
log = tk.Text(root, height=8, bg="black", fg="cyan"); log.pack(fill="x")
ent = tk.Entry(root, bg="#111", fg="white"); ent.pack(fill="x")
def L(s): log.insert("end", s); log.see("end")
def draw():
    t = time.time(); cv.delete("all")
    for i in range(1, 4): cv.create_oval(60-i*14, 40-i*14, 360+i*14, 380+i*14, outline="#0077aa")
    cv.create_oval(60, 40, 360, 380, outline="#00c8ff", width=3)
    bl = 2 if t % 4 < .15 else 14
    for x in (155, 265): cv.create_oval(x-30, 160-bl, x+30, 160+bl, fill="white", outline="#00e5ff")
    o = abs(math.sin(t*14))*18+3 if talking else 2
    cv.create_oval(165, 300-o, 255, 300+o, outline="#00c8ff", width=3)
    root.after(40, draw)
def speak(a):
    global talking; talking = True
    if tts: tts.say(a); tts.runAndWait()
    else: time.sleep(min(len(a)/12, 8))
    talking = False
def phone(args):
    c = cfg(); base = f"http://{c.get('pip','')}:8765"; h = {"X-Token": c.get("pcode", "")}
    try:
        if args.startswith("ls"): return requests.get(base+"/ls", params={"p": args[2:].strip()}, headers=h, timeout=10).text
        if args.startswith("get "):
            p = args[4:].strip(); d = os.path.join(os.path.expanduser("~"), "Downloads", os.path.basename(p))
            open(d, "wb").write(requests.get(base+"/get", params={"p": p}, headers=h, timeout=120).content); return "Saved " + d
        return requests.get(base+"/cmd", params={"q": args}, headers=h, timeout=10).text   # phone asks owner to confirm sensitive actions
    except Exception as e: return "Phone not reachable: " + str(e)
def send(_=None):
    q = ent.get().strip(); ent.delete(0, "end"); L(f"\nYou: {q}")
    def w():
        if q.startswith("phone "): a = phone(q[6:])
        else:
            s = q.lower().startswith(("search ", "khoj "))
            a = ask(q, s)
        L(f"\nF G: {a}\n"); speak(a)
    threading.Thread(target=w, daemon=True).start()
def setup():
    c = cfg()
    for k, t in (("key", "Gemini API key"), ("pip", "Phone IP"), ("pcode", "Phone pair code (Setup > Phone pair code)")):
        v = sd.askstring("F G", t, initialvalue=c.get(k, ""), parent=root)
        if v is not None: save(**{k: v.strip()})
    L(f"\nThis PC's code (enter on phone): {cfg()['token']}\n")
tk.Button(root, text="Setup / Pair", command=setup).pack()
def run_cmd(q):   # command from phone; always asks the owner first
    if not mb.askyesno("F G", f"Phone says: {q}\nAllow on this PC?"): return
    if q.startswith("open "):
        x = q[5:].strip()
        if "." in x and " " not in x: webbrowser.open(x if x.startswith("http") else "https://" + x)
        else: subprocess.Popen(x, shell=True)
class H(http.server.BaseHTTPRequestHandler):
    def do_GET(s):
        if s.headers.get("X-Token") != cfg().get("token"): s.send_response(403); s.end_headers(); return
        q = urllib.parse.parse_qs(urllib.parse.urlparse(s.path).query).get("q", [""])[0]
        root.after(0, lambda: run_cmd(q)); s.send_response(200); s.end_headers(); s.wfile.write(b"ok")
    def log_message(s, *a): pass
threading.Thread(target=lambda: http.server.HTTPServer(("", 8766), H).serve_forever(), daemon=True).start()
ent.bind("<Return>", send); draw(); L("F G ready. Setup / Pair first. 'phone <cmd>' controls phone, 'search ...' uses web.\n"); root.mainloop()
