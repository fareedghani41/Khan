package com.fg.jarvis
import android.content.Context
import android.speech.tts.*
import java.util.Locale

object Speaker {
  @Volatile var talking = false
  var tts: TextToSpeech? = null
  fun init(c: Context) { if (tts != null) return
    tts = TextToSpeech(c.applicationContext) { tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
      override fun onStart(u: String?) { talking = true }
      override fun onDone(u: String?) { talking = false }
      @Deprecated("") override fun onError(u: String?) { talking = false } }) } }
  fun say(c: Context, text: String, lang: String = "en") { init(c)
    tts?.language = Locale.forLanguageTag(lang)
    tts?.setPitch(c.getSharedPreferences("fg", 0).getFloat("pitch", 1f))   // girl 1.25 / man 0.8
    tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u") }
}
