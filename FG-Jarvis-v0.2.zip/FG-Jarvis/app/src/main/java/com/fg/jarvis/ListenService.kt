package com.fg.jarvis
import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.os.*
import android.speech.*
import java.io.File
import java.net.*

/** Always-on background mic (visible notification with Stop button). Say "Jarvis ..." or "F G ..." to command. Also serves the PC pairing port. */
class ListenService : Service() {
  private val h = Handler(Looper.getMainLooper()); private var sr: SpeechRecognizer? = null; @Volatile private var on = true
  override fun onBind(i: Intent?): IBinder? = null
  override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
    if (i?.action == "stop") { on = false; stopSelf(); return START_NOT_STICKY }
    Brain.channel(this); Speaker.init(this)
    val stop = PendingIntent.getService(this, 1, Intent(this, ListenService::class.java).setAction("stop"), PendingIntent.FLAG_IMMUTABLE)
    val n = Notification.Builder(this, "fg").setContentTitle("F G Jarvis: microphone is ON").setContentText("Say 'Jarvis ...' to command")
      .setSmallIcon(android.R.drawable.ic_btn_speak_now).setOngoing(true).addAction(Notification.Action.Builder(0, "STOP", stop).build()).build()
    startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
    on = true; loop(); server(); return START_STICKY }
  private fun loop() { if (!on) return
    sr?.destroy(); sr = SpeechRecognizer.createSpeechRecognizer(this)
    sr!!.setRecognitionListener(object : RecognitionListener {
      override fun onResults(r: Bundle) { r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { heard(it) }; h.postDelayed({ loop() }, 400) }
      override fun onError(e: Int) { h.postDelayed({ loop() }, 1000) }
      override fun onReadyForSpeech(p: Bundle?) {} override fun onBeginningOfSpeech() {} override fun onRmsChanged(v: Float) {}
      override fun onBufferReceived(b: ByteArray?) {} override fun onEndOfSpeech() {} override fun onPartialResults(b: Bundle?) {} override fun onEvent(t: Int, b: Bundle?) {} })
    sr!!.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)) }
  private fun heard(t: String) { if (Speaker.talking) return
    Regex("(?:jarvis|f g|ef ji)[ ,]*(.*)", RegexOption.IGNORE_CASE).find(t)?.let { Brain.handle(this, it.groupValues[1]) } }
  private fun server() { Thread { try { val s = ServerSocket(8765); while (on) { val c = s.accept(); Thread { serve(c) }.start() } } catch (e: Exception) { } }.start() }
  private fun serve(c: Socket) { c.use {
    val br = c.getInputStream().bufferedReader(); val line = br.readLine() ?: return; val hd = HashMap<String, String>()
    while (true) { val x = br.readLine(); if (x.isNullOrEmpty()) break; val i = x.indexOf(':'); if (i > 0) hd[x.substring(0, i).lowercase()] = x.substring(i + 1).trim() }
    val out = c.getOutputStream()
    fun send(code: Int, b: ByteArray) { out.write("HTTP/1.1 $code OK\r\nContent-Length: ${b.size}\r\nConnection: close\r\n\r\n".toByteArray()); out.write(b) }
    if (hd["x-token"] != getSharedPreferences("fg", 0).getString("pair", "!")) return send(403, "no".toByteArray())
    val path = URLDecoder.decode(line.split(" ")[1], "UTF-8"); val arg = path.substringAfter("=", "")
    when { path.startsWith("/cmd") -> { Brain.handle(this, arg); send(200, "ok".toByteArray()) }   // sensitive ones still need YES on phone
      path.startsWith("/ls") -> send(200, (File(arg.ifEmpty { "/sdcard" }).listFiles()?.joinToString("\n") { (if (it.isDirectory) "d " else "f ") + it.name } ?: "").toByteArray())
      path.startsWith("/get") -> send(200, File(arg).readBytes())
      else -> send(200, "pong".toByteArray()) } } }
  override fun onDestroy() { on = false; sr?.destroy() }
}
