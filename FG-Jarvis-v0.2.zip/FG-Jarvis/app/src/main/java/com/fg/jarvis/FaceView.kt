package com.fg.jarvis
import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.*

/** Holographic animated face: blinking glowing eyes, lips move while talking. */
class FaceView(c: Context) : View(c) {
  val talking get() = Speaker.talking
  private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(0, 190, 255); style = Paint.Style.STROKE; strokeWidth = 4f; setShadowLayer(20f, 0f, 0f, Color.CYAN) }
  private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(60, 0, 160, 255) }
  private val eye = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; setShadowLayer(25f, 0f, 0f, Color.CYAN) }
  private val t0 = System.currentTimeMillis()
  init { setLayerType(LAYER_TYPE_SOFTWARE, null) }
  override fun onDraw(cv: Canvas) {
    val t = (System.currentTimeMillis() - t0) / 1000f
    val w = width.toFloat(); val h = height.toFloat(); val cx = w / 2; val cy = h / 2; val r = min(w, h) * 0.38f
    cv.drawColor(Color.BLACK)
    for (i in 1..3) cv.drawCircle(cx, cy, r * (1.15f + i * 0.12f), glow.apply { alpha = 90 / i })
    glow.alpha = 255
    val face = RectF(cx - r * .75f, cy - r, cx + r * .75f, cy + r)
    cv.drawOval(face, fill); cv.drawOval(face, glow)
    val blink = if ((t % 4f) < 0.15f) 0.1f else 1f
    val eyeY = cy - r * .22f + sin(t * 1.3f) * 3f
    for (s in listOf(-1, 1)) cv.drawOval(RectF(cx + s * r * .33f - r * .17f, eyeY - r * .07f * blink, cx + s * r * .33f + r * .17f, eyeY + r * .07f * blink), eye)
    val open = if (talking) (abs(sin(t * 14f)) * .5f + .15f) * r * .22f else 2f
    val my = cy + r * .5f
    val mouth = Path().apply { moveTo(cx - r * .27f, my); quadTo(cx, my - open, cx + r * .27f, my); quadTo(cx, my + open * 1.6f + 4f, cx - r * .27f, my) }
    cv.drawPath(mouth, fill.apply { alpha = 120 }); cv.drawPath(mouth, glow)
    fill.alpha = 60
    postInvalidateOnAnimation()
  }
}
