package com.fg.jarvis
import android.Manifest
import android.app.Activity
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.telephony.SmsManager
import java.io.File

/** Runs ONE sensitive action, only after the owner taps YES on the confirmation notification. */
class ActionActivity : Activity() {
  override fun onCreate(s: Bundle?) { super.onCreate(s)
    val a = intent.getStringExtra("a") ?: ""; val b = intent.getStringExtra("b") ?: ""
    try { when (val t = intent.getStringExtra("t")) {
      "open" -> startActivity(packageManager.getLaunchIntentForPackage(a))
      "url" -> startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(a)))
      "call" -> startActivity(Intent(if (checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:$a")))
      "sms" -> SmsManager.getDefault().sendTextMessage(a, null, b, null, null)
      "wa" -> startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/${a.filter { it.isDigit() }}?text=" + Uri.encode(b))))
      "selfie", "photo", "video" -> {
        val vid = t == "video"; val v = ContentValues().apply { put(MediaStore.MediaColumns.DISPLAY_NAME, "FG_${System.currentTimeMillis()}") }
        val u = contentResolver.insert(if (vid) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)
        startActivity(Intent(if (vid) MediaStore.ACTION_VIDEO_CAPTURE else MediaStore.ACTION_IMAGE_CAPTURE).putExtra(MediaStore.EXTRA_OUTPUT, u)
          .putExtra("android.intent.extras.CAMERA_FACING", if (t == "selfie") 1 else 0).putExtra("android.intent.extra.USE_FRONT_CAMERA", t == "selfie")) }
      "del" -> startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$a")))
      "install" -> startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=" + Uri.encode(a))))
      "rm" -> File(a).deleteRecursively()
      "loc" -> Brain.shareLocation(this)
      "tap" -> Brain.say(this, if (JarvisAccess.tap(a)) "Tapped $a" else "Could not tap $a (is Accessibility on?)")
      "type" -> Brain.say(this, if (JarvisAccess.type(a)) "Typed" else "No text box focused")
    } } catch (e: Exception) { Brain.say(this, "Error: ${e.message}") }
    finish() }
}
