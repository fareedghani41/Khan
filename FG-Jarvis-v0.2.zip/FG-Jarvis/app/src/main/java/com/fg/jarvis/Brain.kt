package com.fg.jarvis
import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.location.LocationManager
import android.os.Environment
import android.provider.ContactsContract
import android.accessibilityservice.AccessibilityService
import java.io.File
import java.net.*

object Brain {
  var log: ((String) -> Unit)? = null
  fun say(c: Context, t: String, lang: String = "en") { log?.invoke("F G: $t"); Speaker.say(c, t, lang) }
  fun root() = Environment.getExternalStorageDirectory()
  fun channel(c: Context) { val nm = c.getSystemService(NotificationManager::class.java)
    nm.createNotificationChannel(NotificationChannel("fg", "F G", NotificationManager.IMPORTANCE_LOW))
    nm.createNotificationChannel(NotificationChannel("fgc", "F G confirm", NotificationManager.IMPORTANCE_HIGH)) }
  /** Every sensitive action = notification with YES button. Nothing runs without it. */
  fun confirm(c: Context, label: String, type: String, a: String = "", b: String = "") {
    channel(c)
    val pi = PendingIntent.getActivity(c, (System.nanoTime() and 0xffffff).toInt(), Intent(c, ActionActivity::class.java).putExtra("t", type).putExtra("a", a).putExtra("b", b),
      PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    val n = Notification.Builder(c, "fgc").setContentTitle("F G: confirm?").setContentText(label).setSmallIcon(android.R.drawable.ic_dialog_info)
      .addAction(Notification.Action.Builder(0, "YES", pi).build()).setAutoCancel(true).build()
    c.getSystemService(NotificationManager::class.java).notify((System.nanoTime() and 0xffff).toInt(), n)
    say(c, "$label. Confirm karne ke liye notification mein YES dabayein.") }
  fun findApp(c: Context, n: String): Pair<String, String>? { val pm = c.packageManager
    return pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
      .firstOrNull { it.loadLabel(pm).toString().lowercase().contains(n) }?.let { it.loadLabel(pm).toString() to it.activityInfo.packageName } }
  fun contact(c: Context, n: String): String? {
    if (n.matches(Regex("[+0-9 ]{5,}"))) return n.replace(" ", "")
    if (c.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
    c.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
      "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$n%"), null)?.use { if (it.moveToFirst()) return it.getString(0) }
    return null }
  fun shareLocation(c: Context) {
    if (c.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return say(c, "Location permission needed")
    val lm = c.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    val l = lm.getProviders(true).mapNotNull { lm.getLastKnownLocation(it) }.maxByOrNull { it.time } ?: return say(c, "No location yet")
    c.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, "https://maps.google.com/?q=${l.latitude},${l.longitude}"), "Send location").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
  fun reply(c: Context, user: String, search: Boolean) { val p = c.getSharedPreferences("fg", 0)
    Thread { val r = Gemini.chat(p.getString("key", "")!!, Gemini.sys("Farid Ghani", p.getString("mem", "")!!), user, search)
      say(c, r.replace(Regex("^\\[lang:[^]]*]\\s*"), ""), Regex("^\\[lang:([a-zA-Z-]+)]").find(r)?.groupValues?.get(1) ?: "en") }.start() }

  fun handle(c: Context, raw: String) {
    val t = raw.trim(); if (t.isEmpty()) return; val l = t.lowercase(); log?.invoke("You: $t")
    val p = c.getSharedPreferences("fg", 0)
    fun m(r: String) = Regex(r).find(l)?.groupValues
    if ("voice" in l || "awaz" in l) {
      if (Regex("girl|female|ladki").containsMatchIn(l)) { p.edit().putFloat("pitch", 1.25f).apply(); return say(c, "Okay, girl voice.") }
      if (Regex("\\bman\\b|\\bmale\\b|ladka|\\bboy\\b").containsMatchIn(l)) { p.edit().putFloat("pitch", 0.8f).apply(); return say(c, "Okay, man voice.") } }
    m("(?:yaad rakh\\w*|remember)\\s+(.*)")?.let { p.edit().putString("mem", p.getString("mem", "") + "; " + it[1]).apply() }
    m("^(?:web search|search|khoj|google)\\s+(.+)")?.let { return reply(c, "Search the web and answer briefly: ${it[1]}", true) }
    m("^(?:open|kholo)\\s+(.+)")?.let { val x = it[1].trim()
      if (x.matches(Regex("\\S+\\.\\w{2,}"))) return confirm(c, "Open $x?", "url", if (x.startsWith("http")) x else "https://$x")
      val a = findApp(c, x) ?: return say(c, "App $x not found"); return confirm(c, "Open ${a.first}?", "open", a.second) }
    m("^(?:call|phone)\\s+(.+)")?.let { val n = contact(c, it[1].trim()) ?: return say(c, "Contact not found"); return confirm(c, "Call ${it[1]}?", "call", n) }
    m("^(?:sms|msg|message)\\s+(\\S+)\\s+(.+)")?.let { val n = contact(c, it[1]) ?: return say(c, "Contact not found"); return confirm(c, "SMS to ${it[1]}: ${it[2]}", "sms", n, it[2]) }
    m("^whatsapp\\s+(\\S+)\\s*(.*)")?.let { val n = contact(c, it[1]) ?: return say(c, "Contact not found"); return confirm(c, "Open WhatsApp chat with ${it[1]}?", "wa", n, it[2]) }
    m("^contact\\s+(.+)")?.let { return say(c, contact(c, it[1]) ?: "Not found") }
    m("(selfie|photo|video)")?.let { if (Regex("^(take|le|record|selfie|photo|video)").containsMatchIn(l)) return confirm(c, "Open camera for ${it[1]}?", it[1]) }
    m("^uninstall\\s+(.+)")?.let { val a = findApp(c, it[1]) ?: return say(c, "App not found"); return confirm(c, "Uninstall ${a.first}?", "del", a.second) }
    m("^install\\s+(.+)")?.let { return confirm(c, "Search ${it[1]} on Play Store?", "install", it[1]) }
    m("^(?:create folder|folder banao)\\s+(.+)")?.let { return say(c, if (File(root(), it[1]).mkdirs()) "Folder created" else "Could not create (all files access on?)") }
    m("^(?:list files|files)\\s*(.*)")?.let { return say(c, File(root(), it[1]).listFiles()?.take(15)?.joinToString(", ") { f -> f.name } ?: "Empty or no access") }
    m("^(?:delete|remove)\\s+(?:file|folder)\\s+(.+)")?.let { return confirm(c, "Delete ${it[1]}?", "rm", File(root(), it[1]).path) }
    m("^tap\\s+(.+)")?.let { return confirm(c, "Tap '${it[1]}' on screen?", "tap", it[1]) }
    m("^type\\s+(.+)")?.let { return confirm(c, "Type '${it[1]}'?", "type", it[1]) }
    if (l == "back") return void(JarvisAccess.global(AccessibilityService.GLOBAL_ACTION_BACK))
    if (l == "home") return void(JarvisAccess.global(AccessibilityService.GLOBAL_ACTION_HOME))
    if ("location" in l) return confirm(c, "Share current location?", "loc")
    m("^pc\\s+(.+)")?.let { q -> val ip = p.getString("pcip", ""); val code = p.getString("pccode", "")
      Thread { try { val u = URL("http://$ip:8766/cmd?q=" + URLEncoder.encode(q[1], "UTF-8")).openConnection() as HttpURLConnection
        u.setRequestProperty("X-Token", code); u.connectTimeout = 5000; say(c, if (u.responseCode == 200) "Sent to PC" else "PC refused") } catch (e: Exception) { say(c, "PC not reachable") } }.start(); return }
    reply(c, t, false) }
  private fun void(x: Any?) {}
}
