package com.fg.jarvis
import android.util.Base64
import org.json.*
import java.net.*

object Gemini {
  val models = listOf("gemini-2.5-flash", "gemini-2.0-flash", "gemini-2.0-flash-lite", "gemini-1.5-flash")
  fun call(key: String, system: String, parts: JSONArray, search: Boolean = false): String {
    if (key.isBlank()) return "[lang:en] Please set your Gemini API key first."
    for (m in models) try {
      val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent?key=$key").openConnection() as HttpURLConnection
      c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 60000
      c.setRequestProperty("Content-Type", "application/json")
      val body = JSONObject().put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
        .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
      if (search) body.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
      c.outputStream.use { it.write(body.toString().toByteArray()) }
      if (c.responseCode != 200) continue
      val ps = JSONObject(c.inputStream.bufferedReader().readText()).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts")
      return (0 until ps.length()).joinToString("") { ps.getJSONObject(it).optString("text") }.trim()
    } catch (e: Exception) { }
    return "[lang:en] Could not reach Gemini (check key / internet)."
  }
  fun chat(key: String, sys: String, user: String, search: Boolean = false) = call(key, sys, JSONArray().put(JSONObject().put("text", user)), search)
  fun audio(key: String, sys: String, prompt: String, data: ByteArray) = call(key, sys, JSONArray().put(JSONObject().put("text", prompt))
    .put(JSONObject().put("inline_data", JSONObject().put("mime_type", "audio/ogg").put("data", Base64.encodeToString(data, Base64.NO_WRAP)))))
  fun sys(owner: String, mem: String) = "You are F G, a smart, friendly, respectful voice assistant of $owner (call him boss/sir politely). " +
    "ALWAYS start reply with [lang:xx] (ISO code of the language the user used) and reply in that same language. Keep replies short and natural for speech. Known notes: $mem"
}
