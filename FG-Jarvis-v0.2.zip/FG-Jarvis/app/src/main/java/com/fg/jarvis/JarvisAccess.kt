package com.fg.jarvis
import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.view.accessibility.*

/** Lets F G tap/type inside other apps (Instagram, Snapchat, Chrome...). Owner must enable it in Accessibility settings. */
class JarvisAccess : AccessibilityService() {
  companion object {
    var i: JarvisAccess? = null
    fun tap(t: String): Boolean { val n = i?.rootInActiveWindow?.findAccessibilityNodeInfosByText(t)?.firstOrNull() ?: return false
      var x: AccessibilityNodeInfo? = n; while (x != null && !x.isClickable) x = x.parent
      return x?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false }
    fun type(t: String): Boolean { val f = i?.rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
      val b = Bundle(); b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t)
      return f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b) }
    fun global(a: Int) = i?.performGlobalAction(a)
  }
  override fun onServiceConnected() { i = this }
  override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
  override fun onInterrupt() {}
}
