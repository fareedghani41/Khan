package com.fg.jarvis
import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.*
import android.graphics.Color
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.text.InputType
import android.widget.*

class MainActivity : Activity() {
  lateinit var log: TextView; lateinit var input: EditText; lateinit var p: SharedPreferences
  override fun onCreate(b: Bundle?) {
    super.onCreate(b); p = getSharedPreferences("fg", 0); Speaker.init(this)
    if (p.getString("pair", "").isNullOrEmpty()) p.edit().putString("pair", (10000000..99999999).random().toString()).apply()
    requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.POST_NOTIFICATIONS,
      Manifest.permission.CALL_PHONE, Manifest.permission.SEND_SMS, Manifest.permission.READ_CONTACTS), 1)
    val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.BLACK) }
    root.addView(FaceView(this), LinearLayout.LayoutParams(-1, 0, 1f))
    log = TextView(this).apply { setTextColor(Color.CYAN); text = "F G ready, Farid sir. Say 'Jarvis ...'" }
    root.addView(ScrollView(this).apply { addView(log) }, LinearLayout.LayoutParams(-1, 0, .6f))
    input = EditText(this).apply { setTextColor(Color.WHITE); hint = "Type a command"; setHintTextColor(Color.GRAY) }; root.addView(input)
    val row = LinearLayout(this)
    fun btn(t: String, f: () -> Unit) = row.addView(Button(this).apply { text = t; textSize = 11f; setOnClickListener { f() } }, LinearLayout.LayoutParams(0, -2, 1f))
    btn("Send") { val t = input.text.toString(); input.setText(""); Brain.handle(this, t) }
    btn("Mic ON") { startListen() }
    btn("Auto") { toggleAuto() }
    btn("Setup") { setup() }
    root.addView(row); setContentView(root)
    Brain.log = { s -> runOnUiThread { log.append("\n\n$s") } }
  }
  override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) { startListen() }
  fun startListen() { if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == 0) startForegroundService(Intent(this, ListenService::class.java)) }
  fun toggleAuto() { val on = !p.getBoolean("auto", false)
    if (on && !Settings.Secure.getString(contentResolver, "enabled_notification_listeners").orEmpty().contains(packageName)) {
      startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")); return Brain.say(this, "Allow notification access, then tap Auto again.") }
    p.edit().putBoolean("auto", on).apply(); Brain.say(this, if (on) "Automation ON. I reply as Farid's assistant." else "Automation OFF.") }
  fun ask(title: String, key: String, cb: (() -> Unit)? = null) { val e = EditText(this).apply { setText(p.getString(key, "")); inputType = InputType.TYPE_CLASS_TEXT }
    AlertDialog.Builder(this).setTitle(title).setView(e).setPositiveButton("Save") { _, _ -> p.edit().putString(key, e.text.toString().trim()).apply() }.show() }
  fun setup() = AlertDialog.Builder(this).setItems(arrayOf("Gemini API key", "PC IP address", "PC pair code", "Accessibility (control apps)", "All files access", "Phone pair code (for PC)")) { _, i ->
    when (i) { 0 -> ask("Gemini API key", "key"); 1 -> ask("PC IP", "pcip"); 2 -> ask("PC code", "pccode")
      3 -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
      4 -> startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
      5 -> AlertDialog.Builder(this).setMessage("Phone pair code: ${p.getString("pair", "")}").show() } }.show()
}
