package com.fg.jarvis
import android.app.Notification
import android.app.RemoteInput
import android.content.Intent
import android.os.Bundle
import android.service.notification.*
import java.io.File

/** Auto-reply to WhatsApp private chats (text + voice notes). Only when owner turns Auto ON. Always says it is the assistant. */
class AutoReplyService : NotificationListenerService() {
  private val last = HashMap<String, Long>()
  private fun latestVoice(): ByteArray? {
    val d = File("/storage/emulated/0/Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Voice Notes")
    return d.walkTopDown().filter { it.extension == "opus" && System.currentTimeMillis() - it.lastModified() < 120000 }.maxByOrNull { it.lastModified() }?.readBytes() }
  override fun onNotificationPosted(sbn: StatusBarNotification) {
    val p = getSharedPreferences("fg", 0)
    if (!p.getBoolean("auto", false) || sbn.packageName != "com.whatsapp") return
    val n = sbn.notification; val ex = n.extras
    if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0 || ex.getBoolean("android.isGroupConversation")) return
    val who = ex.getString("android.title") ?: return
    val msg = ex.getCharSequence("android.text")?.toString() ?: return
    if (System.currentTimeMillis() - (last[who] ?: 0) < 20000) return
    val act = n.actions?.firstOrNull { it.remoteInputs?.isNotEmpty() == true } ?: return
    last[who] = System.currentTimeMillis()
    Thread {
      val owner = p.getString("owner", "Farid Ghani")!!
      val s = Gemini.sys(owner, p.getString("mem", "")!!) + " You are replying to $who on $owner's behalf. Be friendly, brief, in their language. Never claim to be $owner. " +
        "Say you are $owner's assistant and $owner will see it later. Do not promise money or sensitive actions."
      val key = p.getString("key", "")!!
      val voice = if (msg.contains("🎤") || msg.contains("voice message", true)) latestVoice() else null
      var r = (if (voice != null) Gemini.audio(key, s, "Understand this voice message and reply to the sender.", voice) else Gemini.chat(key, s, msg)).replace(Regex("^\\[lang:[^]]*]\\s*"), "")
      if (!r.contains("assistant", true)) r = "I am $owner's Assistant. $r"
      val ri = act.remoteInputs!![0]; val i = Intent(); val b = Bundle(); b.putCharSequence(ri.resultKey, r)
      RemoteInput.addResultsToIntent(act.remoteInputs, i, b)
      try { act.actionIntent.send(this, 0, i) } catch (e: Exception) { }
    }.start()
  }
}
